package com.example.airhockey.models;

public class Ball {

}