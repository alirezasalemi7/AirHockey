package com.example.airhockey.models;

import com.example.airhockey.models.Ball;
import com.example.airhockey.models.Striker;

public class Board {
    private Striker myStrikerView;
    private Striker oponentStrikerView;
    private Ball ball;
}