package com.example.airhockey.models;

public interface ConnectionStates {
    int STATE_IDLE = 0;
    int STATE_LISTENING = 1;
    int STATE_CONNECTING = 2;
    int STATE_CONNECTED = 3;
}
