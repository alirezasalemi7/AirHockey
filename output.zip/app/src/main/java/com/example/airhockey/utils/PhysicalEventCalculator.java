package com.example.airhockey.utils;

// this is a static class
public class PhysicalEventCalculator {

}