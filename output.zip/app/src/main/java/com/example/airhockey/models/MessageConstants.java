package com.example.airhockey.models;

public interface MessageConstants {
    int MESSAGE_READ = 0;
    int MESSAGE_WRITE = 1;
}
