package com.example.airhockey.utils;

//static class
public class ScoreCounter {

}